Pokemon Go Encryption Library
===

This is a Reverse Engineered implementation of the Pokémon GO encryption
algorythim, as implemeted in the 0.31 release of Pokémon GO.

This Reverse Engineering was done under the auspices of the Australian
Copyright Act, section 47D.

For more information, please see https://pgoapi.com/legal.html

